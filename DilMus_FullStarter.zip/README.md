
DilMus Full Starter
===================

What's included:
- Flutter starter app with Auth (Google), Player, Upload screen (uploads to Firebase Storage + song doc)
- Firestore-based songs streaming (approved flag)
- Firebase Cloud Function stub (logPlay) to record plays
- Instructions below to connect Firebase and run

How to run (high-level):

1) Install Flutter SDK & tools
2) Create Firebase project, enable Auth (Google), Firestore, Storage, Functions
3) Download google-services.json (Android) and GoogleService-Info.plist (iOS) and place them:
   - Android: android/app/google-services.json
   - iOS: ios/Runner/GoogleService-Info.plist
4) In functions folder, run `npm install` and deploy functions: `firebase deploy --only functions`
5) From project root:
   flutter pub get
   flutter run
6) Approve uploaded songs from Firestore (admin) by setting approved=true for song docs.

Security:
- Update Firestore rules and Storage rules before production.
- Do server-side crediting for wallet to avoid fraud.
