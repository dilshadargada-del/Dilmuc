Admin panel scaffold: create a React app and use firebase-admin to approve songs and manage payouts.
