
class Song {
  final String id;
  final String title;
  final String artistId;
  final String artistName;
  final String url;
  final String coverUrl;
  final int duration;
  final bool isPremium;
  final double price;

  Song({required this.id, required this.title, required this.artistId, required this.artistName, required this.url, required this.coverUrl, required this.duration, this.isPremium=false, this.price=0.0});
}
