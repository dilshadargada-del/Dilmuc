
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'screens/splash.dart';
import 'services/auth_service.dart';
import 'package:provider/provider.dart';
import 'services/player_service.dart';
import 'services/songs_repository.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const DilMusApp());
}

class DilMusApp extends StatelessWidget {
  const DilMusApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider(create: (_) => AuthService()),
        Provider(create: (_) => PlayerService()),
        Provider(create: (_) => SongsRepository()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DilMus',
        theme: ThemeData.dark(),
        home: const SplashScreen(),
      ),
    );
  }
}
