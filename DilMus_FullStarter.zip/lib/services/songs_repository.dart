
import 'package:cloud_firestore/cloud_firestore.dart';

class SongsRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<List<Map<String, dynamic>>> streamApprovedSongs() {
    return _db.collection('songs').where('approved', isEqualTo: true).snapshots().map((snap) =>
      snap.docs.map((d) => d.data()..['id'] = d.id).toList()
    );
  }

  Future<String> uploadSongMetadata(Map<String, dynamic> data) async {
    final doc = await _db.collection('songs').add(data);
    return doc.id;
  }
}
