
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';

class PlayerService {
  final AudioPlayer _player = AudioPlayer();

  PlayerService() {
    _init();
  }

  Future<void> _init() async {
    final session = await AudioSession.instance;
    await session.configure(const AudioSessionConfiguration.music());
  }

  Future<void> setUrl(String url) async {
    await _player.setUrl(url);
  }

  void play() => _player.play();
  void pause() => _player.pause();
  void stop() => _player.stop();

  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<Duration> get positionStream => _player.positionStream;
  AudioPlayer get audioPlayer => _player;
}
