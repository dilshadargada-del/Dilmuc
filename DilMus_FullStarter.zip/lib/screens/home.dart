
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/songs_repository.dart';
import '../services/player_service.dart';
import 'player_screen.dart';
import 'upload_song.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final repo = Provider.of<SongsRepository>(context);
    final player = Provider.of<PlayerService>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('DilMus')),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.upload),
        onPressed: () { Navigator.push(context, MaterialPageRoute(builder: (_) => const UploadSongScreen())); },
      ),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: repo.streamApprovedSongs(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final songs = snapshot.data!;
          return ListView.builder(
            itemCount: songs.length,
            itemBuilder: (context, index) {
              final s = songs[index];
              return ListTile(
                leading: Image.asset('assets/logo.png', width:50, height:50),
                title: Text(s['title'] ?? 'Unknown'),
                subtitle: Text(s['artistName'] ?? ''),
                trailing: IconButton(icon: const Icon(Icons.play_arrow), onPressed: () async {
                  await player.setUrl(s['storageUrl'] ?? s['url']);
                  Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(url: s['storageUrl'] ?? s['url'], title: s['title'] ?? 'Playing')));
                }),
              );
            },
          );
        },
      ),
    );
  }
}
