
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/player_service.dart';

class PlayerScreen extends StatefulWidget {
  final String url;
  final String title;
  const PlayerScreen({Key? key, required this.url, required this.title}) : super(key: key);

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late PlayerService playerService;

  @override
  void initState() {
    super.initState();
    playerService = Provider.of<PlayerService>(context, listen: false);
    playerService.setUrl(widget.url).then((_) => playerService.play());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          const SizedBox(height:20),
          Image.asset('assets/logo.png', width:200, height:200),
          const SizedBox(height:20),
          StreamBuilder<Duration?>(
            stream: playerService.durationStream,
            builder: (context, snap) {
              final total = snap.data ?? Duration.zero;
              return StreamBuilder<Duration>(
                stream: playerService.positionStream,
                builder: (context, snap2) {
                  final pos = snap2.data ?? Duration.zero;
                  return Column(children: [
                    Slider(min:0, max: total.inMilliseconds.toDouble(), value: pos.inMilliseconds.clamp(0, total.inMilliseconds).toDouble(), onChanged: (v){ playerService.audioPlayer.seek(Duration(milliseconds: v.toInt())); }),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_format(pos)), Text(_format(total))])
                  ]);
                },
              );
            },
          ),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            IconButton(iconSize:48, icon: const Icon(Icons.pause), onPressed: () => playerService.pause()),
            IconButton(iconSize:64, icon: const Icon(Icons.play_arrow), onPressed: () => playerService.play()),
            IconButton(iconSize:48, icon: const Icon(Icons.stop), onPressed: () => playerService.stop()),
          ])
        ],
      ),
    );
  }

  String _format(Duration d) {
    String two(int n) => n.toString().padLeft(2,'0');
    return "${two(d.inMinutes.remainder(60))}:${two(d.inSeconds.remainder(60))}";
  }
}
