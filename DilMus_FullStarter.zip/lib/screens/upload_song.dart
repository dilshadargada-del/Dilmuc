
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UploadSongScreen extends StatefulWidget {
  const UploadSongScreen({Key? key}) : super(key: key);

  @override
  State<UploadSongScreen> createState() => _UploadSongScreenState();
}

class _UploadSongScreenState extends State<UploadSongScreen> {
  String? _fileName;
  String? _filePath;
  final _titleCtrl = TextEditingController();

  Future<void> pickAndUpload() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (res == null) return;
    final file = res.files.single;
    setState(() { _fileName = file.name; });
    final bytes = file.bytes;
    final uid = FirebaseAuth.instance.currentUser?.uid ?? 'anon';
    final ref = FirebaseStorage.instance.ref().child('songs/$uid/${file.name}');
    await ref.putData(bytes!);
    final url = await ref.getDownloadURL();
    await FirebaseFirestore.instance.collection('songs').add({
      'title': _titleCtrl.text,
      'artistId': uid,
      'artistName': FirebaseAuth.instance.currentUser?.displayName ?? '',
      'storageUrl': url,
      'approved': false,
      'createdAt': FieldValue.serverTimestamp(),
    });
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Uploaded - pending approval')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Upload Song')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(children: [
          TextField(controller: _titleCtrl, decoration: const InputDecoration(labelText: 'Song Title')),
          const SizedBox(height:12),
          ElevatedButton.icon(onPressed: pickAndUpload, icon: const Icon(Icons.upload_file), label: const Text('Pick & Upload')),
          if (_fileName != null) Padding(padding: const EdgeInsets.all(8.0), child: Text('Selected: $_fileName')),
        ]),
      ),
    );
  }
}
