
DilMus - Music Player Starter (Flutter)
--------------------------------------

What's included:
- pubspec.yaml (dependencies: just_audio, audio_session, provider)
- lib/main.dart (home & navigation)
- lib/player_screen.dart (player UI & logic)
- assets/logo.png (placeholder)

How to run:
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Extract the project.
3. From the project root, run:
   flutter pub get
   flutter run

Notes:
- The app uses network MP3 files from bensound.com as example tracks.
- To add your own tracks, replace the 'url' fields in PlayerModel.songs or add local assets.
- For iOS, add required audio background modes and AVAudioSession setup as per just_audio docs.

If you want, I can also add Firebase + offline download next.
