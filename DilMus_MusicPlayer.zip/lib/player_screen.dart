
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:audio_session/audio_session.dart';
import 'package:provider/provider.dart';

class PlayerModel extends ChangeNotifier {
  final List<Map<String, String>> songs = [
    {
      'title': 'Acoustic Breeze',
      'artist': 'Bensound (example)',
      'url': 'https://www.bensound.com/bensound-music/bensound-acousticbreeze.mp3'
    },
    {
      'title': 'Better Days',
      'artist': 'Bensound (example)',
      'url': 'https://www.bensound.com/bensound-music/bensound-betterdays.mp3'
    },
    {
      'title': 'Sunny',
      'artist': 'Bensound (example)',
      'url': 'https://www.bensound.com/bensound-music/bensound-sunny.mp3'
    },
  ];

  final AudioPlayer _player = AudioPlayer();
  int currentIndex = -1;

  AudioPlayer get player => _player;

  Future<void> setUrl(int index) async {
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration.music());
      currentIndex = index;
      await _player.setUrl(songs[index]['url']!);
      notifyListeners();
    } catch (e) {
      print('Error setting url: $e');
    }
  }

  void play() => _player.play();
  void pause() => _player.pause();
  void stop() => _player.stop();
  void seek(Duration position) => _player.seek(position);

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}

class PlayerScreen extends StatefulWidget {
  final int index;
  const PlayerScreen({Key? key, required this.index}) : super(key: key);

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  late PlayerModel model;
  late AudioPlayer player;

  @override
  void initState() {
    super.initState();
    model = Provider.of<PlayerModel>(context, listen: false);
    player = model.player;
    // load & play
    model.setUrl(widget.index).then((_) => model.play());
  }

  @override
  void dispose() {
    super.dispose();
  }

  String formatDuration(Duration? d) {
    if (d == null) return "--:--";
    String two(int n) => n.toString().padLeft(2, '0');
    final minutes = two(d.inMinutes.remainder(60));
    final seconds = two(d.inSeconds.remainder(60));
    return "$minutes:$seconds";
  }

  @override
  Widget build(BuildContext context) {
    final song = model.songs[widget.index];
    return Scaffold(
      appBar: AppBar(title: Text(song['title']!)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.asset('assets/logo.png', width: 200, height: 200),
            const SizedBox(height: 16),
            Text(song['title']!, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            Text(song['artist']!),
            const SizedBox(height: 16),
            StreamBuilder<Duration?>(
              stream: player.durationStream,
              builder: (context, snapshot) {
                final total = snapshot.data ?? Duration.zero;
                return StreamBuilder<Duration>(
                  stream: player.positionStream,
                  builder: (context, snapshotPos) {
                    final pos = snapshotPos.data ?? Duration.zero;
                    return Column(
                      children: [
                        Slider(
                          min: 0,
                          max: total.inMilliseconds.toDouble(),
                          value: pos.inMilliseconds.clamp(0, total.inMilliseconds).toDouble(),
                          onChanged: (v) {
                            player.seek(Duration(milliseconds: v.toInt()));
                          },
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(formatDuration(pos)),
                            Text(formatDuration(total)),
                          ],
                        )
                      ],
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  iconSize: 48,
                  icon: const Icon(Icons.pause_circle_filled),
                  onPressed: () => model.pause(),
                ),
                const SizedBox(width: 20),
                IconButton(
                  iconSize: 64,
                  icon: const Icon(Icons.play_circle_filled),
                  onPressed: () => model.play(),
                ),
                const SizedBox(width: 20),
                IconButton(
                  iconSize: 48,
                  icon: const Icon(Icons.stop_circle_outlined),
                  onPressed: () => model.stop(),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
