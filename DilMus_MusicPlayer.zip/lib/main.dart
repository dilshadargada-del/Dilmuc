
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'player_screen.dart';

void main() {
  runApp(const DilMusApp());
}

class DilMusApp extends StatelessWidget {
  const DilMusApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => PlayerModel(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DilMus Player',
        theme: ThemeData.dark(),
        home: const HomePage(),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final songs = Provider.of<PlayerModel>(context, listen: false).songs;
    return Scaffold(
      appBar: AppBar(title: const Text('DilMus - Music Player')),
      body: ListView.builder(
        itemCount: songs.length,
        itemBuilder: (context, index) {
          final s = songs[index];
          return ListTile(
            leading: Image.asset('assets/logo.png', width: 50, height: 50),
            title: Text(s['title']),
            subtitle: Text(s['artist']),
            trailing: IconButton(
              icon: const Icon(Icons.play_arrow),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(index: index)));
              },
            ),
          );
        },
      ),
    );
  }
}
